/*
 * libssc: Library to expose Qualcomm Sensor Core sensors
 * Copyright (C) 2022-2026 Dylan Van Assche
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef _LIBSSC_H_
#define _LIBSSC_H_

#include <libssc-sensor.h>
#include <libssc-sensor-accelerometer.h>
#include <libssc-sensor-compass.h>
#include <libssc-sensor-light.h>
#include <libssc-sensor-proximity.h>
#include <libssc-sensor-gyroscope.h>

#endif /* _LIBSSC_H_ */
